/**
 * jquery.RotatAnim - jQuery Rotation Animation
 * Version 0.1 Beta 
 *
 * Written by
 * Juan Vallejo (juuanv@gmail.com)
 * 
 * Dependencies
 * jQuery (http://jquery.com)
 * 
 **/

For full documentation and latest release, visit:
http://juanjvallejo.com/files/rnd