/**
 * jquery.RotatAnim - jQuery Rotation Animation
 * 
 * Written by
 * Juan Vallejo (juuanv@gmail.com)
 * 
 * Dependencies
 * jQuery (http://jquery.com)
 * 
 **/
 
(function($) {
	$.fn.RotatAnim = function(tar,num) {
		var deg;
		var lim;
		var last;
			this.click(function rotate() {
				deg++;
				if(deg > 360) { deg = 0; lim = 0; }
				$(tar).css({
							'-webkit-transform':'rotate('+deg+'deg)',
							'-moz-transform':'rotate('+deg+'deg)',
							'-o-transform':'rotate('+deg+'deg)',
							'-ms-transform':'rotate('+deg+'deg)',
							'transform':'rotate('+deg+'deg)'
							});
				if(deg < lim) {
					setTimeout(rotate,5);
				} else {
					deg = 0;
				}
			});
		deg = 0;
		lim = num;
		last = 0;
	};
}) (jQuery);